let x = prompt("Podaj liczbę x");
let y = prompt("Podaj liczbę y");

if (x > y)  {
    document.write("Liczba x jest większa");
}  else  {
    document.write("Liczba y jest większa");
}