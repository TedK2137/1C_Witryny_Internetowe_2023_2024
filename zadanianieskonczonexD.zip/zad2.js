let wynik = prompt("Podaj wynik testu: ")

if (wynik >= 90) {
    document.write("Ocena: A");
} else if (wynik <= 89 && wynik >= 80){
    document.write("Ocena: B");
} else if (wynik <= 79 && wynik >= 70){
    document.write("Ocena: C");
} else if (wynik < 70){
    document.write("Ocena: D");
}